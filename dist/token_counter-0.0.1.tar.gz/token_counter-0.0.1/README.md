![](https://img.shields.io/badge/language-Python%203.9%20%2B-blue)
![](https://img.shields.io/badge/coverage-98%25-green)

本项目用于Python自定义第三方模块的打包。

## 打包(build)

```bash
python3 -m pip install --upgrade build
pip3 install hatchling
python -m build
```

## 上传(upload)

```bash
python3 -m pip install --upgrade twine
twine upload -u < user_name > -p < password > -r nexus --repository-url https://prod-tanka-sg-nexus.aws.tankaapps.com/repository/pypi-ai-releases/ dist/*
```

## 安装(install)

```bash
pip install unified_logger==0.0.1 -i 
```

## 如何在项目中使用


add the url, e.g.

```
https://prod-tanka-sg-nexus.aws.tankaapps.com/repository/pypi-ai-releases/packages/unified-logger/0.0.1/unified_logger-0.0.1.tar.gz
```

## 如何在代码中使用

```
import unified_logger
from config import PROJECT_DIR, PROJECT_NAME
from config.config_parser import LOG_NAMESPACE, LOG_PATH


logger = unified_logger.Logger(PROJECT_DIR, PROJECT_NAME, LOG_NAMESPACE, LOG_PATH)

class Fool:
    def func(self, a):
        logger.log_setter("public", "true", _input="asdf", function="func")

```
